import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { BookService } from '../books/book.service';
import { Book } from '../../models/book';

@Component({
  selector: 'app-book-detail',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './book-detail.html',
  styleUrl: './book-detail.css',
})
export class BookDetailComponent implements OnInit {
  id!: number;
  book?: Book;

  form = new FormGroup({
    title: new FormControl('', [Validators.required]),
    author: new FormControl('', [Validators.required]),
    genre: new FormControl('', [Validators.required]),
    status: new FormControl<'TO_READ' | 'READING' | 'READ'>('TO_READ', [Validators.required]),
    rating: new FormControl<number>(0),
  });

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private bookService: BookService
  ) {}

  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    const found = this.bookService.getById(this.id);

    if (!found) {
      this.router.navigate(['/livros']);
      return;
    }

    this.book = found;

    this.form.patchValue({
      title: found.title,
      author: found.author,
      genre: found.genre,
      status: found.status,
      rating: found.rating ?? 0,
    });
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const status = this.form.get('status')!.value!;
    const rating = status === 'READ' ? Number(this.form.get('rating')!.value ?? 0) : 0;

    const updated: Omit<Book, 'id'> = {
      title: this.form.get('title')!.value ?? '',
      author: this.form.get('author')!.value ?? '',
      genre: this.form.get('genre')!.value ?? '',
      status,
      rating,
    };

    this.bookService.update(this.id, updated);
    this.router.navigate(['/livros']);
  }

  delete(): void {
    this.bookService.delete(this.id);
    this.router.navigate(['/livros']);
  }
}