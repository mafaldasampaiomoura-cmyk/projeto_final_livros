import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { StatusLabelPipe } from '../../shared/shared/pipes/status-label.pipe';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusLabelPipe],
  templateUrl: './book-list.html',
  styleUrl: './book-list.css',
})

type BookStatus = 'READ' | 'READING' | 'TO_READ';

interface Book {
  id: number;
  title: string;
  author: string;
  genre: string;
  status: BookStatus;
  rating: number;
}

export class BookListComponent {
  searchText = '';
  sortBy: 'title' | 'rating' = 'title';
  statusFilter: '' | 'READ' | 'READING' | 'TO_READ' = '';

  constructor(private router: Router) {}

  editBook(id: number) {
    this.router.navigate(['/books', id]);
  }

  
  deleteBook(id: number) {
    
  }

  filteredBooks() {
   
    return []; 
  }
}